package a

func Foo() {}
